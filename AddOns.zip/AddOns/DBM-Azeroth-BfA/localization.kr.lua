if GetLocale() ~= "koKR" then return end
local L

-----------------------
-- T'zane --
-----------------------
L= DBM:GetModLocalization(2139)

-----------------------
-- Ji'arak --
-----------------------
L= DBM:GetModLocalization(2141)

-----------------------
-- Hailstone Construct --
-----------------------
L= DBM:GetModLocalization(2197)

-----------------------
-- Azurethos, The Winged Typhoon --
-----------------------
L= DBM:GetModLocalization(2199)

-----------------------
-- Doom's Howl/ Lion's Roar --
-----------------------
L= DBM:GetModLocalization(2213)

L= DBM:GetModLocalization(2212)

-----------------------
-- Warbringer Yenajz --
-----------------------
L= DBM:GetModLocalization(2198)

-----------------------
-- Dunegorger Kraulok --
-----------------------
L= DBM:GetModLocalization(2210)

-----------------------
-- Ivus (Two Faction Versions) --
-----------------------
L= DBM:GetModLocalization(2345)--Ivus the Decayed

L= DBM:GetModLocalization(2329)--Ivus the Forest Lord

-----------------------
-- Ulmath, the Soulbinder --
-----------------------
L= DBM:GetModLocalization(2362)

-----------------------
-- Wekemara --
-----------------------
L= DBM:GetModLocalization(2363)
